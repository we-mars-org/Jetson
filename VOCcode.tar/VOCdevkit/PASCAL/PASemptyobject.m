function object=PASemptyobject
  object.label='';
  object.orglabel='';
  object.bbox=[];
  object.polygon=[];
  object.mask='';
return